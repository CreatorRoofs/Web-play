//Переменныые для старта игры
let startBnt = document.getElementById("start_btn")
//Переменные для 1 этапа
    let input_first_stage = document.getElementById("input_first_stage")
    let accept_first_stage = document.getElementById("accept_first_stage")
    let first_stage = document.getElementById("first_stage")
    let answer_first_stage = document.getElementById("answer_first_stage")
//Переменные для 2 этапа
let second_stage = document.getElementById("second_stage")
let img1_second_stage = document.getElementById("img1_second_stage")
let img2_second_stage = document.getElementById("img2_second_stage")
let answer_second_stage = document.getElementById("answer_second_stage")
//Переменные для 3 этапа
let third_stage = document.getElementById("third_stage")
let hp_monster_third_stage = document.getElementById("hp_monster_third_stage")
let hp_user_third_stage = document.getElementById("hp_user_third_stage")
let attack_third_stage = document.getElementById("attack_third_stage")
let healing_third_stage = document.getElementById("healing_third_stage")
let title_next_stage = document.getElementById("title_next_stage")
let game_over_visible = document.getElementById("game_over_visible")
//Переменные для 4 этапа
let four_stage = document.getElementById("four_stage")
let true_btn_four_stage = document.getElementById("true_btn_four_stage")
let next_btn_four_stage = document.getElementById("next_btn_four_stage")
//Переменные для 5 этапа
let five_stage = document.getElementById("five_stage")
//Старт Игры
startBnt.addEventListener("click", () => {
    first_stage.classList.remove("hide")
    first_stage.classList.add("visible_first_stage")
})

const ChangePage = (arg1, arg2) => {
    arg1.classList.remove(`visible_${arg1.id}`)
    arg1.classList.add("hide")
    arg2.classList.remove("hide")
    arg2.classList.add(`visible_${arg2.id}`)
}

//1 Этап
const chekAnswer_1 = () => {
    if (input_first_stage.value == 4){
        answer_first_stage.textContent = "Ответ правильный, пререходим на следующий этап...";
        setTimeout(() => {
            answer_first_stage.textContent = ""
            input_first_stage.value = ""
            ChangePage(first_stage,second_stage)
        }, 2000)
    } else {
        answer_first_stage.textContent = "Ответ неправильный";
    }
}
accept_first_stage.addEventListener("click", chekAnswer_1)
//Этап 2
const trueImg = () => {
    setTimeout(() => {
        answer_second_stage.textContent = ""
        ChangePage(second_stage,third_stage)
    }, 2000)
    answer_second_stage.textContent = "Да, всё круто, загружаю следующий вопрос...";
}
img2_second_stage.addEventListener("click", trueImg)
const falseImg = () => {
    answer_second_stage.textContent = "Нет, подумай ещё";
}
img1_second_stage.addEventListener("click", falseImg)

//Этап 3

let hpMonster = 100;
let hpUser = 100;

hp_monster_third_stage.textContent = hpMonster;
hp_user_third_stage.textContent = hpUser;

const Random = (min, max) => Math.floor(Math.random() * (max-min) + min)

const getAttack = () => {
    hpMonster -= Random(2,7);
    hp_monster_third_stage.textContent = hpMonster;

    if(hpMonster <= 0){
        title_next_stage.textContent = "Вы победили монстра!";
        setTimeout(() => {
        hp_monster_third_stage.textContent = "100";
        hp_user_third_stage.textContent = "100";
        hpUser = "100"
        hpMonster = "100"
        title_next_stage.textContent = ""
        ChangePage(third_stage,four_stage)
        }, 3000)
    }
    hpUser -= Random(4,10);
    hp_user_third_stage.textContent = hpUser;

    if(hpUser <= 0){
        game_over_visible.classList.remove("hide")
        game_over_visible.classList.add("game_over_visible")
        setTimeout(() => {
            hp_monster_third_stage.textContent = "100";
            hp_user_third_stage.textContent = "100";
            hpUser = "100"
            hpMonster = "100"
            game_over_visible.classList.remove("game_over_visible")
            game_over_visible.classList.add("hide")
            third_stage.classList.remove("visible_third_stage")
            third_stage.classList.add("hide")
            four_stage.classList.remove("visible_four_stage")
            four_stage.classList.add("hide")
        }, 2000)
    }

}
const goHeal = () => {
    hpUser += 5;
    hp_user_third_stage.textContent = hpUser;
}

attack_third_stage.addEventListener("click", getAttack)
healing_third_stage.addEventListener("click", goHeal)

// Этап 4

const findBtn = () => {
    next_btn_four_stage.classList.remove("hide")
    next_btn_four_stage.classList.add("btn_visible_four_next_stage")
    true_btn_four_stage.classList.add("findButton")
}
true_btn_four_stage.addEventListener("click", findBtn)

next_btn_four_stage.addEventListener("click", () => {
    next_btn_four_stage.classList.remove("btn_visible_four_next_stage")
    next_btn_four_stage.classList.add("hide")
    true_btn_four_stage.classList.remove("findButton")
    ChangePage(four_stage, five_stage)
})
